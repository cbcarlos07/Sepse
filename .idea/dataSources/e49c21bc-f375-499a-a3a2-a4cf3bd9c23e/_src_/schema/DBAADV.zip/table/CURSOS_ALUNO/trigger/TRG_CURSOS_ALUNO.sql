CREATE TRIGGER TRG_CURSOS_ALUNO
BEFORE INSERT
  ON CURSOS_ALUNO
FOR EACH ROW
  declare
   QTDE NUMBER(4);
begin

   SELECT COUNT(*) INTO QTDE FROM CURSOS_ALUNO F WHERE F.NR_CPF = :NEW.NR_CPF;

   IF QTDE > 0 THEN
           raise_application_error (-20999,'CPF já cadastrado anteriormente');
   END IF;   
    
end TRG_CURSOS_ALUNO;
/
