CREATE VIEW VDIC_HAM_PROTOCOLO_SEPSE AS SELECT DISTINCT
          SETOR
         ,CD_PED_LAB
         ,to_char(DATA_PEDIDO,'dd/mm/yyyy hh24:mi:ss') "DATA PEDIDO"
         ,PACIENTE
         ,LAUDO
         ,BIOQUIMICO



         ,CASE
            WHEN(maior_hr)  <  0.766666
              THEN 'CONFORME'
            WHEN (maior_hr) >= 0.766666
              THEN
                CASE
                    WHEN TRUNC(MAIOR_HR) < 10
                        THEN 0||TRUNC(MAIOR_HR)  || CASE WHEN trunc(MAIOR_MIN) < 10 THEN ':0'||trunc(MAIOR_MIN)||':00'
                                                         WHEN trunc(MAIOR_MIN) >= 10 THEN ':'||trunc(MAIOR_MIN)||':00'
                                                     END

                    WHEN TRUNC(MAIOR_HR) >= 10
                        THEN ''||TRUNC(MAIOR_HR) || CASE WHEN trunc(MAIOR_MIN) < 10  THEN 0||trunc(MAIOR_MIN)||':00'
                                                         WHEN trunc(MAIOR_MIN) >= 10 THEN ':'||trunc(MAIOR_MIN)||':00'
                                                     END
               END
            END TEMPO_TOTAL



         ,
                CASE
                    WHEN TRUNC(MAIOR_HR) < 10
                        THEN 0||TRUNC(MAIOR_HR)  || CASE WHEN trunc(MAIOR_MIN) < 10 THEN ':0'||trunc(MAIOR_MIN)||':00'
                                                         WHEN trunc(MAIOR_MIN) >= 10 THEN ':'||trunc(MAIOR_MIN)||':00'
                                                     END

                    WHEN TRUNC(MAIOR_HR) >= 10
                        THEN ''||TRUNC(MAIOR_HR) || CASE WHEN trunc(MAIOR_MIN) < 10  THEN 0||trunc(MAIOR_MIN)||':00'
                                                         WHEN trunc(MAIOR_MIN) >= 10 THEN ':'||trunc(MAIOR_MIN)||':00'
                                                     END

            END TEMPO_TOTAL1



         ,MAIOR_HR



         ,CASE
            WHEN(maior_hr)  <  0.766666
              THEN 'CONFORME'
            WHEN (maior_hr) >= 0.766666
              THEN
                CASE
              WHEN TO_CHAR(((maior_hr - 0.766666))) > maior_hr
                THEN CASE
                       WHEN TO_CHAR((TRUNC((maior_hr - 0.766666)*60))+1) < 10
                         THEN 0||TO_CHAR((TRUNC((maior_hr - 0.766666)*60))+1)||' minuto(s)'
                     ELSE TO_CHAR((TRUNC((maior_hr - 0.766666)*60))+1)||' minuto(s)'
                      END
               ELSE TO_CHAR((TRUNC((maior_hr - 0.766666)*60))+1)||' minuto(s)'
              END
            END TEMPO



         ,CASE
            WHEN   TRUNC(MAIOR_HR) = 0 AND (MAIOR_MIN) > 45 OR MAIOR_HR >= 1
               THEN
                   'vermelha'

            WHEN (TRUNC(MAIOR_HR) = 0  and (MAIOR_MIN) > 40 and (MAIOR_MIN) <= 45)
               THEN
                   'verde'

            WHEN TRUNC(MAIOR_HR) = 0   and (MAIOR_MIN) <= 40
               THEN
                   'verde'
          END INDICADOR
          ,LACTATO
          ,LEUCO
          ,PLAQUETAS
          ,DATA_FILTRO
          ,TP_ATENDIMENTO
          ,1 CONTADOR


    FROM (


          SELECT  (PEDIDO_LAUDO/60) hr_PC
                  ,mod(trunc(PEDIDO_LAUDO),60)     min_PC
                  ,PACIENTE
                  ,CD_PED_LAB
                  ,DATA_PEDIDO

                  ,(MAIOR/60) MAIOR_HR
                  ,MOD(TRUNC(MAIOR),60) MAIOR_MIN
                  ,LAUDO
                  ,LACTATO
                  ,LEUCO
                  ,PLAQUETAS
                  ,SETOR
                  ,DATA_FILTRO
                  ,TP_ATENDIMENTO
                  ,BIOQUIMICO


            FROM (


                  SELECT  SUM(((DATA_LAUDO    - DATA_PEDIDO)*24)*60)/SUM(TOTAL)    PEDIDO_LAUDO

                         ,PACIENTE
                         ,CD_PED_LAB
                         ,DATA_PEDIDO
                         ,LACTATO
                         ,LEUCO
                         ,PLAQUETAS
                         ,MAX(MAIOR) MAIOR
                         ,MAX(DATA_LAUDO) LAUDO
                         ,SETOR
                         ,DATA_FILTRO
                         ,TP_ATENDIMENTO
                         ,BIOQUIMICO

                    FROM (


                            SELECT (DATA_PEDIDO) DATA_PEDIDO
                                   ,DATA_COLETA
                                   ,DATA_LAUDO
                                   ,PACIENTE
                                   ,CD_PED_LAB
                                   ,TOTAL
                                   ,SETOR



                                   ,((DATA_LAUDO - DATA_PEDIDO)*24)*60 MAIOR
                                   ,LACTATO
                                   ,LEUCO
                                   ,PLAQUETAS

                                   ,DATA_FILTRO
                                   ,TP_ATENDIMENTO
                                  -- ,length(BIOQUIMICO) BIOQUIMICO
                                   ,CASE
                                       WHEN length(BIOQUIMICO) <= 4
                                         THEN (SELECT (PRESTADOR.NM_MNEMONICO) FROM PRESTADOR WHERE PRESTADOR.CD_PRESTADOR = BIOQUIMICO)
                                       ELSE BIOQUIMICO
                                      END BIOQUIMICO
                                 --  ,BIOQUIMICO
                              FROM (

                                    SELECT   NM_SETOR SETOR
                                            ,P.NM_PACIENTE PACIENTE
                                            ,MAX(IL.CD_USUARIO_ASSINADO) KEEP (DENSE_RANK LAST ORDER BY IL.DT_ASSINADO) BIOQUIMICO
                                            ,PL.CD_PED_LAB
                                            ,MIN(AM.DT_COLETA_SETOR)                                      DATA_COLETA
                                            ,NVL(PM.DH_IMPRESSAO,TO_DATE(to_char(PL.DT_PEDIDO,'dd/mm/yyyy')||' '||to_char(PL.HR_PED_LAB,'HH24:MI:SS'),'DD/MM/YYYY HH24:MI:SS')) DATA_PEDIDO
                                            ,MAX(IL.DT_ASSINADO)                                          DATA_LAUDO
                                            ,1 TOTAL
                                           ,(SELECT DS_RESULTADO
                                                FROM RES_EXA
                                               WHERE CD_EXA_LAB = 1523
                                                 AND NM_CAMPO = 'CLAC'
                                                 AND CD_PED_LAB = PL.CD_PED_LAB
                                                ) LACTATO

                                            ,(SELECT DS_RESULTADO
                                                FROM RES_EXA
                                               WHERE CD_EXA_LAB = 1472
                                                 AND NM_CAMPO = 'LEUCÓCITOS'
                                                 AND CD_PED_LAB = PL.CD_PED_LAB
                                             ) LEUCO

                                            ,(SELECT DS_RESULTADO
                                                FROM RES_EXA
                                               WHERE CD_EXA_LAB = 1472
                                                 AND NM_CAMPO = 'PLAQUETAS'
                                                 AND CD_PED_LAB = PL.CD_PED_LAB
                                              ) PLAQUETAS
                                           ,PM.DH_IMPRESSAO DATA_FILTRO
                                           ,A.TP_ATENDIMENTO

                                        FROM DBAMV.EXA_LAB            EL
                                            ,DBAMV.PED_LAB            PL
                                            ,DBAMV.ITPED_LAB          IL
                                            ,DBAMV.PRE_MED            PM
                                            ,DBAMV.ITPRE_MED          IPM
                                            ,DBAMV.TIP_PRESC          TP
                                            ,DBAMV.ATENDIME           A
                                            ,DBAMV.AMOSTRA_EXA_LAB    AME
                                            ,DBAMV.AMOSTRA            AM
                                            ,DBAMV.COLETA_MATERIAL    CM
                                            ,PACIENTE                 P
                                            ,SETOR

                                       WHERE EL.CD_EXA_LAB          = IL.CD_EXA_LAB
                                         AND PL.CD_PED_LAB          = IL.CD_PED_LAB
                                         AND PL.CD_ATENDIMENTO      = A.CD_ATENDIMENTO
                                         AND PM.CD_ATENDIMENTO      = A.CD_ATENDIMENTO
                                         AND PM.CD_PRE_MED          = IPM.CD_PRE_MED
                                         AND TP.CD_TIP_PRESC        = IPM.CD_TIP_PRESC
                                         AND TP.CD_EXA_LAB          = EL.CD_EXA_LAB
                                         AND AME.CD_ITPED_LAB       = IL.CD_ITPED_LAB
                                         AND AME.CD_AMOSTRA         = AM.CD_AMOSTRA
                                         AND AM.CD_COLETA_MATERIAL  = CM.CD_COLETA_MATERIAL
                                         AND CM.CD_PED_LAB          = IL.CD_PED_LAB
                                         AND A.CD_PACIENTE          = P.CD_PACIENTE
                                         AND PL.CD_PRE_MED          = PM.CD_PRE_MED
                                         AND PL.CD_SETOR            = SETOR.CD_SETOR
                                      --   AND to_char(PM.DH_IMPRESSAO,'mm/yyyy') = '03/2017'
                                         AND (IPM.SN_CANCELADO      =  'N' OR IPM.SN_CANCELADO IS NULL)
                                         AND IL.DT_LAUDO              IS NOT NULL
                                         AND IL.DT_ASSINADO           IS NOT NULL
                                     --    AND PL.CD_PED_LAB = 403291

                                         AND  (EL.CD_EXA_LAB          IN (1472,1479,1478,1480,1473,1474,1475,1476,1481,1482)
                                              OR (EL.CD_EXA_LAB IN (1523) AND TRUNC(PM.DH_IMPRESSAO) > '22/12/2015'))
                                         AND  (TP.CD_EXA_LAB          IN (1472,1479,1478,1480,1473,1474,1475,1476,1481,1482)
                                              OR (EL.CD_EXA_LAB IN (1523) AND TRUNC(PM.DH_IMPRESSAO) > '22/12/2015'))
GROUP BY NM_SETOR
        ,P.NM_PACIENTE
        ,PL.CD_PED_LAB
        ,PM.DH_IMPRESSAO
        ,PL.DT_PEDIDO
        ,PL.HR_PED_LAB
        ,A.TP_ATENDIMENTO
ORDER BY 2

                               )

                            )
                         GROUP BY PACIENTE, CD_PED_LAB, DATA_PEDIDO,LACTATO,LEUCO,PLAQUETAS,SETOR,DATA_FILTRO,TP_ATENDIMENTO,BIOQUIMICO
                     )
             )

ORDER  BY 1,3,2
/
