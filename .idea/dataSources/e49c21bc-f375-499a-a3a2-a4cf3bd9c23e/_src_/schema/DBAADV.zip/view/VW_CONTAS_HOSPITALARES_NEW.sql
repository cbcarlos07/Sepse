CREATE VIEW VW_CONTAS_HOSPITALARES_NEW AS select
  to_char(nvl(reg.dt_final,ate.dt_alta),'YYYYMM') anomes,
  ate.cd_atendimento,
  reg.cd_reg_fat conta,
  trunc(ate.dt_atendimento) dt_atendimento,
  trunc(ate.dt_alta) dt_alta,
  trunc(reg.dt_inicio) dt_periodo_inicio,
  trunc(reg.dt_final) dt_periodo_fim,
  pac.nm_paciente,
  reg.cd_convenio,
  cnv.nm_convenio,
  ate.tp_atendimento,
  5 cd_ori_ate,
  'INTERNAMENTO' ds_ori_ate,
  ate.cd_prestador,
  med.nm_prestador,
  (select pro.tp_status
   from dbaadv.protocolo pro
   where pro.cd_protocolo = dbaadv.ptc_ret_ult_proto_conta(ate.cd_atendimento, null, reg.cd_reg_fat, 1)
     and pro.cd_setor_destino = 58
  ) as Status_Conta,
  reg.cd_remessa,
  to_char(fat.dt_competencia,'YYYYMM') competencia,
  cnv.hab_tipo,
  case
    when nvl(reg.sn_fechada,'N') = 'N' then 1 --Conta Aberta
    when nvl(reg.sn_fechada,'N') = 'S' and nvl(reg.cd_remessa,0) = 0 then 2 --Conta Fechada
    when nvl(reg.sn_fechada,'N') = 'S' and nvl(reg.cd_remessa,0) > 0 and nvl(rem.sn_fechada,'N') = 'N' then 3 --Remessa Aberta
    when nvl(reg.sn_fechada,'N') = 'S' and nvl(reg.cd_remessa,0) > 0 and nvl(rem.sn_fechada,'N') = 'S' and
      nvl((select distinct j.cd_nota_fiscal
          from dbamv.itfat_nota_fiscal j
          where j.cd_reg_fat = reg.cd_reg_fat),0) = 0 then 4 --Remessa Fechada
    when nvl(reg.sn_fechada,'N') = 'S' and nvl(reg.cd_remessa,0) > 0 and nvl(rem.sn_fechada,'N') = 'S' and
      nvl((select distinct j.cd_nota_fiscal
          from dbamv.itfat_nota_fiscal j
          where j.cd_reg_fat = reg.cd_reg_fat),0) <> 0 then 5 --NF Emitida
  end as status,
  (select pro.cd_setor_destino
   from dbaadv.protocolo pro
   where pro.cd_protocolo = dbaadv.ptc_ret_ult_proto_conta(ate.cd_atendimento, null, reg.cd_reg_fat, 1)
  ) as localizacao,
  sum(ira.vl_total_conta) as valor_total
from dbamv.atendime ate
  join dbamv.ori_ate ori on (ori.cd_ori_ate = ate.cd_ori_ate)
  join dbamv.reg_fat reg on (reg.cd_atendimento = ate.cd_atendimento)
  join dbamv.paciente pac on (pac.cd_paciente = ate.cd_paciente)
  join dbamv.convenio cnv on (cnv.cd_convenio = reg.cd_convenio)
  left join dbamv.itreg_fat ira on (ira.cd_reg_fat = reg.cd_reg_fat)
  left join dbamv.remessa_fatura rem on (rem.cd_remessa = reg.cd_remessa)
  left join dbamv.prestador med on (med.cd_prestador = ate.cd_prestador)
  left join dbamv.fatura fat on (fat.cd_fatura = rem.cd_fatura)
where ate.tp_atendimento = 'I'
--  and ate.cd_convenio = 3
--  and reg.cd_remessa is not null
  and extract(year from nvl(reg.dt_final,ate.dt_alta)) >= 2014
group by
  to_char(nvl(reg.dt_final,ate.dt_alta),'YYYYMM'),
  ate.cd_atendimento,
  reg.cd_reg_fat,
  trunc(ate.dt_atendimento),
  trunc(ate.dt_alta),
  trunc(reg.dt_inicio),
  trunc(reg.dt_final),
  pac.nm_paciente,
  reg.cd_convenio,
  cnv.nm_convenio,
  ate.tp_atendimento,
  5,
  'INTERNAMENTO',
  ate.cd_prestador,
  med.nm_prestador,
  reg.cd_remessa,
  to_char(fat.dt_competencia,'YYYYMM'),
  cnv.hab_tipo,
  reg.sn_fechada,
  rem.sn_fechada
/
