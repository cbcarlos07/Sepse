CREATE VIEW VW_CONTAS_AMBULATORIAS_NEW2 AS select
    to_char(ate.dt_atendimento,'YYYYMM') anomes,
    ate.cd_atendimento,
    ira.cd_reg_amb conta,
    trunc(ate.dt_atendimento) dt_atendimento,
    pac.nm_paciente,
    reg.cd_convenio,
    cnv.nm_convenio,
    ate.tp_atendimento,
    ate.cd_ori_ate,
    ori.ds_ori_ate,
    se.nm_setor,
    ate.cd_prestador,
    med.nm_prestador,
    trunc(x.dthr_recebido) dt_recebimento,
    x.cd_protocolo,
    reg.cd_remessa,
    cnv.hab_tipo,
    proc.cd_pro_fat,
    proc.ds_pro_fat
  from dbamv.atendime ate
    join dbamv.ori_ate ori on (ori.cd_ori_ate = ate.cd_ori_ate)
    join dbamv.itreg_amb ira on (ira.cd_atendimento = ate.cd_atendimento)
    left join dbamv.setor se on (se.cd_setor = ira.cd_setor_produziu)
    join dbamv.reg_amb reg on (reg.cd_reg_amb = ira.cd_reg_amb)
    join dbamv.paciente pac on (pac.cd_paciente = ate.cd_paciente)
    join dbamv.convenio cnv on (cnv.cd_convenio = reg.cd_convenio)
    left join dbamv.pro_fat proc on (proc.cd_pro_fat = ate.cd_pro_int)
    left join dbamv.prestador med on (med.cd_prestador = ate.cd_prestador)
    left join (select /*+INDEX(dbaadv.IDX_IT_PROTOCOLO_09)*/ itp.cd_atendimento, itp.cd_reg_amb, pro.dthr_recebido, itp.cd_protocolo
               from dbaadv.it_protocolo itp
                 join dbaadv.protocolo pro on (pro.cd_protocolo = itp.cd_protocolo
                                           and pro.cd_setor_destino = 58
                                           and pro.tp_status = 'R')
               where itp.tp_verificado = 1
                 and itp.cd_protocolo = (select max(a.cd_protocolo)
                                         from dbaadv.protocolo a
                                           join dbaadv.it_protocolo b on (b.cd_protocolo = a.cd_protocolo)
                                         where b.cd_atendimento = itp.cd_atendimento
                                           and b.cd_reg_amb = itp.cd_reg_amb)) x on (x.cd_atendimento = ate.cd_atendimento
                                                                                 and x.cd_reg_amb = reg.cd_reg_amb)
  where ate.tp_atendimento <> 'I'
--    and extract(year from ate.dt_atendimento) >= 2014
--    and ira.cd_pro_fat not in ('00103182','00103183','00103184','00103185')
--    and not (ate.cd_ori_ate = 3 and ira.tp_mvto = 'Prescricao')
  group by
    to_char(ate.dt_atendimento,'YYYYMM'),
    ate.cd_atendimento,
    ira.cd_reg_amb,
    trunc(ate.dt_atendimento),
    pac.nm_paciente,
    reg.cd_convenio,
    cnv.nm_convenio,
    ate.tp_atendimento,
    ate.cd_ori_ate,
    ori.ds_ori_ate,
    se.nm_setor,
    ate.cd_prestador,
    med.nm_prestador,
    trunc(x.dthr_recebido),
    x.cd_protocolo,
    reg.cd_remessa,
    cnv.hab_tipo,
    proc.cd_pro_fat,
    proc.ds_pro_fat
/
