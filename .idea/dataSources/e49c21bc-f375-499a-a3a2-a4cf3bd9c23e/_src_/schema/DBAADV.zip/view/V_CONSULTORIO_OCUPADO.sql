CREATE VIEW V_CONSULTORIO_OCUPADO AS SELECT OCP.CD_PRESTADOR
      ,IND
      ,MAQUINA
  FROM (

SELECT DECODE(IND,NULL,0,IND) IND
      ,TODOS.CD_PRESTADOR
  FROM (

        SELECT CASE
                 WHEN COUNT(*) > 0
                   THEN 1
                 ELSE 0
               END IND
              ,CD_PRESTADOR
          FROM (
                 SELECT MIN(DC.DH_CRIACAO) ATD_MEDICO
                        ,A.CD_ATENDIMENTO
                        ,a.cd_prestador
                    FROM DBAMV.IT_AGENDA_CENTRAL IAC
                        ,DBAMV.AGENDA_CENTRAL     AC
                        ,ATENDIME                 A
                        ,DBAMV.PW_DOCUMENTO_CLINICO DC
                        ,TRIAGEM_ATENDIMENTO TA
                        ,PACIENTE            P
                        ,DBAMV.AVISO_CIRURGIA AV
                   WHERE IAC.CD_ATENDIMENTO(+)    = A.CD_ATENDIMENTO
                     AND IAC.CD_AGENDA_CENTRAL    = AC.CD_AGENDA_CENTRAL(+)
                     AND A.CD_ATENDIMENTO         = DC.CD_ATENDIMENTO(+)
                     AND A.CD_ATENDIMENTO         = TA.CD_ATENDIMENTO(+)
                     AND A.CD_PACIENTE            = P.CD_PACIENTE
                     AND AV.CD_PACIENTE(+)        = P.CD_PACIENTE
                     AND A.CD_ORI_ATE = 1
                     AND A.TP_ATENDIMENTO = 'A'
                     AND to_char(A.DT_ATENDIMENTO,'DD/MM/YYYY') = TO_CHAR(SYSDATE,'DD/MM/YYYY')
                     AND DC.DH_CRIACAO IS NULL

                GROUP BY a.cd_prestador
                        ,A.CD_ATENDIMENTO

                )
      GROUP BY CD_PRESTADOR
      ) AG

       ,(
          SELECT DISTINCT a.cd_prestador
            FROM DBAMV.IT_AGENDA_CENTRAL IAC
                ,DBAMV.AGENDA_CENTRAL     AC
                ,ATENDIME                 A
                ,PACIENTE            P
           WHERE IAC.CD_ATENDIMENTO(+)    = A.CD_ATENDIMENTO
             AND IAC.CD_AGENDA_CENTRAL    = AC.CD_AGENDA_CENTRAL(+)
             AND A.CD_PACIENTE            = P.CD_PACIENTE
             AND A.CD_ORI_ATE = 1
             AND A.TP_ATENDIMENTO = 'A'
             AND to_char(A.DT_ATENDIMENTO,'DD/MM/YYYY') = TO_CHAR(SYSDATE,'DD/MM/YYYY')

          ) TODOS
     WHERE TODOS.CD_PRESTADOR = AG.CD_PRESTADOR(+)





     ) OCP


     ,(SELECT * FROM DBAADV.CONSULTORIO_CACHE) CACHE

  WHERE OCP.CD_PRESTADOR = CACHE.CD_PRESTADOR

--  SELECT * FROM CONSULTORIO_CACHE FOR UPDATE
--SELECT * FROM CONSULTORIO_MEDICO for update
--SELECT
/
