CREATE Procedure        TISS_DEMONST_DATA_PAGTO (
  cd_demonstrativo_in  IN dbaadv.tiss_demonst_pagto_resumo.cd_demonstrativo%TYPE
)
IS
  Cursor c_Pagamentos Is
    Select
        m.id
      , prt.dt_ultimo_pagamento
    from dbamv.tiss_mensagem m
    inner join (
      Select
          p.nr_protocolo
        , p.nr_lote
        , sum(p.vl_liberado)  as vl_liberado
        , max(p.dt_pagamento) as dt_ultimo_pagamento
      from dbaadv.tiss_demonst_pagto_resumo_pr p
      where p.cd_demonstrativo = cd_demonstrativo_in
      group by
          p.nr_protocolo
        , p.nr_lote
    ) prt on (prt.nr_protocolo = m.nr_protocolo_retorno and prt.nr_lote = m.nr_lote)
    where m.tp_transacao = 'DEMONSTRATIVO_ANALISE_CONTA';

  id_mensagem_retorno_ac dbaadv.tiss_demonstrativo_pagto.id_tiss_mensagem_retorno_ac%TYPE;
  dt_ultimo_pagamento    dbaadv.tiss_demonst_pagto_resumo_pr.dt_pagamento%TYPE;
BEGIN

  Open c_Pagamentos;

  Loop
    Fetch c_Pagamentos
    into
        id_mensagem_retorno_ac
      , dt_ultimo_pagamento;

    Exit When c_Pagamentos%NotFound;

    Update dbaadv.tiss_demonstrativo_pagto ac Set
      ac.dt_pagamento = dt_ultimo_pagamento
    where ac.id_tiss_mensagem_retorno_ac = id_mensagem_retorno_ac;

    Commit;

  End Loop;

  Close c_Pagamentos;

  Exception
    When Others Then
      raise_application_error(-20001, 'Demonstrativo : ' || cd_demonstrativo_in || ' -> Erro ao tentar processar retorno importado - ' || SQLCODE || ' - Error - ' || SQLERRM);
END;
/
