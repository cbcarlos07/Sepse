CREATE Procedure        mvs_valida_contrato (
    cd_contrato_in  IN  dbaps.contrato.cd_contrato%TYPE
  , cd_retorno_out  OUT number
  , ds_mensagem_out OUT varchar2
)
IS
  Cursor c_GuiaRetorno Is
    Select
        c.cd_matricula
      , c.nr_cpf_cgc
    from dbaps.contrato c
    where c.cd_contrato = cd_contrato_in;

  v_cd_matricula    dbaps.contrato.cd_matricula%TYPE;
  v_nr_cpf_cgc      dbaps.contrato.nr_cpf_cgc%TYPE;
BEGIN
  /*
  A variável "cd_retorno_out" retornará:
  0 - Contrato inválido
  1 - Contrato válido
  */
  cd_retorno_out  := 1;
  ds_mensagem_out := '';

  Exception
    When Others Then
      begin
         cd_retorno_out  := 0;
         ds_mensagem_out := 'Consulta GSMV - Erro ao tentar validar o contrato informado. Favor informar ao suporte de TI.';
         raise_application_error(-20001, 'Consulta GSMV - Erro ao tentar validar o contrato informado - ' || SQLCODE || ' - Error - ' || SQLERRM);
      end;
END;
/
