CREATE Procedure        TISS_DEMONST_PAGTO_PROCESSAR (
  cd_demonstrativo_in  IN dbaadv.tiss_demonstrativo_pagto.cd_demonstrativo%TYPE
)
IS
  Cursor c_GuiaRetorno Is
    Select
        g.id_guia_envio as id_guia_origem
      , g.id as id_guia_retorno
      , cast(g.nr_guia as varchar2(40)) as nr_guia_retorno
      , g.cd_atendimento
      , g.cd_reg_fat
      , g.cd_reg_amb
      , cast( replace(g.vl_processado_guia, '.', ',') as number(12,2)) as vl_processado
      , cast( replace(g.vl_liberado_guia, '.', ',') as number(12,2))   as vl_liberado
      , cast( replace(g.vl_liberado_guia, '.', ',') as number(12,2))   as vl_recebido
      , cast( replace(g.vl_glosa_guia, '.', ',') as number(12,2))      as vl_glosa
    from dbaadv.tiss_demonstrativo_pagto d
      inner join dbamv.tiss_mensagem m on (m.id = d.id_tiss_mensagem_retorno_ac)
      inner join dbamv.tiss_retorno_demon_conta c on (c.id_pai = m.id)
      inner join dbamv.tiss_retorno_demon_conta_lote l on (l.id_pai = c.id)
      inner join  dbamv.tiss_retorno_demon_conta_guia g on (g.id_pai = l.id)
    where d.cd_demonstrativo = cd_demonstrativo_in;

  Cursor c_ProcedimentoRetorno Is
    Select
        rowNum as cd_sequencial
      , g.id_guia_envio as id_guia_origem
      , p.id_it_envio   as id_procedimento_origem
      , g.id as id_guia_retorno
      , p.id as id_procedimento_retorno
      , cast(p.cd_procedimento as varchar2(15)) as nr_procedimento_retorno
      , cast( replace(p.qt_executada, '.', ',') as number(12,4))   as qt_executada
      , cast( replace(p.vl_processado, '.', ',') as number(12,2))  as vl_processado
      , cast( replace(p.vl_liberado, '.', ',') as number(12,2))    as vl_liberado
      , cast( replace(p.vl_liberado, '.', ',') as number(12,2))    as vl_recebido
      , cast( replace(p.vl_glosado, '.', ',') as number(12,2))     as vl_glosa
    from dbaadv.tiss_demonstrativo_pagto d
      inner join dbamv.tiss_mensagem m on (m.id = d.id_tiss_mensagem_retorno_ac)
      inner join dbamv.tiss_retorno_demon_conta c on (c.id_pai = m.id)
      inner join dbamv.tiss_retorno_demon_conta_lote l on (l.id_pai = c.id)
      inner join dbamv.tiss_retorno_demon_conta_guia g on (g.id_pai = l.id)
      inner join dbamv.tiss_retorno_demon_conta_proc p on (p.id_pai = g.id)
    where d.cd_demonstrativo = cd_demonstrativo_in;

  Cursor c_GlosaRetorno(id_guia_in in number, id_procedimento_in in number) Is
    Select
        rowNum as cd_sequencial_glosa
      , substr(gp.cd_motivo_glosa, 1, 10)    as cd_motivo_glosa
      , substr(gp.ds_motivo_glosa, 1, 250)   as ds_motivo_glosa
      , cast( replace(gp.vl_glosa, '.', ',') as number(12,2)) as vl_motivo_glosa
    from dbaadv.tiss_demonstrativo_pagto d
      inner join dbamv.tiss_mensagem m on (m.id = d.id_tiss_mensagem_retorno_ac)
      inner join dbamv.tiss_retorno_demon_conta c on (c.id_pai = m.id)
      inner join dbamv.tiss_retorno_demon_conta_lote l on (l.id_pai = c.id)
      inner join dbamv.tiss_retorno_demon_conta_guia g on (g.id_pai = l.id)
      inner join dbamv.tiss_retorno_demon_conta_proc p on (p.id_pai = g.id)
      inner join dbamv.tiss_retorno_demon_conta_prc_g gp on (gp.id_pai = p.id)
    where d.cd_demonstrativo = cd_demonstrativo_in
      and g.id = id_guia_in
      and p.id = id_procedimento_in;

  id_guia_origem       dbamv.tiss_retorno_demon_conta_guia.id_guia_envio%TYPE;
  id_guia_retorno      dbamv.tiss_retorno_demon_conta_guia.id%TYPE;
  nr_guia_retorno      dbaadv.tiss_demonstrativo_pagto_guia.nr_guia_retorno%TYPE;
  id_procedimento_origem     dbamv.tiss_retorno_demon_conta_proc.id_it_envio%TYPE;
  id_procedimento_retorno    dbamv.tiss_retorno_demon_conta_proc.id%TYPE;
  nr_procedimento_retorno    dbaadv.tiss_demonstrativo_pagto_proc.nr_procedimento_retorno%TYPE;
  cd_sequencial              dbaadv.tiss_demonstrativo_pagto_proc.cd_sequencial%TYPE;
  cd_atendimento       dbamv.tiss_retorno_demon_conta_guia.cd_atendimento%TYPE;
  cd_reg_fat           dbamv.tiss_retorno_demon_conta_guia.cd_reg_fat%TYPE;
  cd_reg_amb           dbamv.tiss_retorno_demon_conta_guia.cd_reg_amb%TYPE;
  vl_processado        dbaadv.tiss_demonstrativo_pagto_guia.vl_processado%TYPE;
  vl_liberado          dbaadv.tiss_demonstrativo_pagto_guia.vl_liberado%TYPE;
  vl_recebido          dbaadv.tiss_demonstrativo_pagto_guia.vl_recebido%TYPE;
  vl_glosa             dbaadv.tiss_demonstrativo_pagto_guia.vl_glosa%TYPE;
  qt_executada         dbaadv.tiss_demonstrativo_pagto_proc.qt_executada%TYPE;
  cd_sequencial_glosa  dbaadv.tiss_demonstrativo_pagto_glosa.cd_sequencial%TYPE;
  cd_motivo_glosa      dbaadv.tiss_demonstrativo_pagto_glosa.cd_motivo_glosa%TYPE;
  ds_motivo_glosa      dbaadv.tiss_demonstrativo_pagto_glosa.ds_motivo_glosa%TYPE;
  vl_motivo_glosa      dbaadv.tiss_demonstrativo_pagto_glosa.vl_glosa%TYPE;
BEGIN

  -- 1. Excluir Registro do processamento anterior
  Delete from dbaadv.tiss_demonstrativo_pagto_guia dg
  where dg.cd_demonstrativo = cd_demonstrativo_in;

  Delete from dbaadv.tiss_demonstrativo_pagto_proc dp
  where dp.cd_demonstrativo = cd_demonstrativo_in;

  Delete from dbaadv.tiss_demonstrativo_pagto_glosa dg
  where dg.cd_demonstrativo = cd_demonstrativo_in;

  -- 2. Buscar Guias de Retorno TISS
  Open  c_GuiaRetorno;
  Fetch c_GuiaRetorno
  into
      id_guia_origem
    , id_guia_retorno
    , nr_guia_retorno
    , cd_atendimento
    , cd_reg_fat
    , cd_reg_amb
    , vl_processado
    , vl_liberado
    , vl_recebido
    , vl_glosa;

  -- 3. Inserir retorno processado (Guias)
  Loop
    if ( id_guia_origem is not null ) then
      Insert Into dbaadv.tiss_demonstrativo_pagto_guia (
          cd_demonstrativo
        , id_guia_origem
        , id_guia_retorno
        , nr_guia_retorno
        , cd_atendimento
        , cd_reg_fat
        , cd_reg_amb
        , vl_processado
        , vl_liberado
        , vl_recebido
        , vl_glosa
      ) values (
          cd_demonstrativo_in
        , id_guia_origem
        , id_guia_retorno
        , nr_guia_retorno
        , cd_atendimento
        , cd_reg_fat
        , cd_reg_amb
        , vl_processado
        , vl_liberado
        , vl_recebido
        , vl_glosa
      );

      Commit;
    End if;

    Fetch c_GuiaRetorno
    into
        id_guia_origem
      , id_guia_retorno
      , nr_guia_retorno
      , cd_atendimento
      , cd_reg_fat
      , cd_reg_amb
      , vl_processado
      , vl_liberado
      , vl_recebido
      , vl_glosa;
    Exit When c_GuiaRetorno%NotFound;
  End Loop;

  Close c_GuiaRetorno;

  -- 4. Buscar Procedimentos de Retorno TISS
  Open  c_ProcedimentoRetorno;
  Fetch c_ProcedimentoRetorno
  into
      cd_sequencial
    , id_guia_origem
    , id_procedimento_origem
    , id_guia_retorno
    , id_procedimento_retorno
    , nr_procedimento_retorno
    , qt_executada
    , vl_processado
    , vl_liberado
    , vl_recebido
    , vl_glosa;

  -- 5. Inserir retorno processado (Procedimentos)
  Loop
    if ( (id_guia_origem is not null) and (id_procedimento_origem is not null) ) then
      Insert Into dbaadv.tiss_demonstrativo_pagto_proc (
          cd_demonstrativo
        , cd_sequencial
        , id_guia_origem
        , id_procedimento_origem
        , id_guia_retorno
        , id_procedimento_retorno
        , nr_procedimento_retorno
        , qt_executada
        , vl_processado
        , vl_liberado
        , vl_recebido
        , vl_glosa
      ) values (
          cd_demonstrativo_in
        , cd_sequencial
        , id_guia_origem
        , id_procedimento_origem
        , id_guia_retorno
        , id_procedimento_retorno
        , nr_procedimento_retorno
        , qt_executada
        , vl_processado
        , vl_liberado
        , vl_recebido
        , vl_glosa
      );

      Commit;
      
      -- 6. Processar as glosas por procedimento
      if (vl_glosa > 0.0) then
        Open  c_GlosaRetorno(id_guia_retorno, id_procedimento_retorno);
        
        Loop
          Fetch c_GlosaRetorno
          into
              cd_sequencial_glosa
            , cd_motivo_glosa
            , ds_motivo_glosa
            , vl_motivo_glosa;

          Exit When c_GlosaRetorno%NotFound;  

          Insert Into dbaadv.tiss_demonstrativo_pagto_glosa (
              cd_demonstrativo
            , cd_sequencial_prc
            , cd_sequencial
            , cd_motivo_glosa
            , ds_motivo_glosa
            , vl_glosa
          ) values (
              cd_demonstrativo_in
            , cd_sequencial
            , cd_sequencial_glosa
            , cd_motivo_glosa
            , ds_motivo_glosa
            , vl_motivo_glosa
          );
          
          Commit;
          
        End Loop;
        
        Close c_GlosaRetorno;  
      End if;  
      
    End if;

    Fetch c_ProcedimentoRetorno
    into
        cd_sequencial
      , id_guia_origem
      , id_procedimento_origem
      , id_guia_retorno
      , id_procedimento_retorno
      , nr_procedimento_retorno
      , qt_executada
      , vl_processado
      , vl_liberado
      , vl_recebido
      , vl_glosa;
    Exit When c_ProcedimentoRetorno%NotFound;
  End Loop;

  Close c_ProcedimentoRetorno;

  Exception
    When Others Then
      raise_application_error(-20001, 'Demonstrativo : ' || cd_demonstrativo_in || ' -> Erro ao tentar processar retorno importado - ' || SQLCODE || ' - Error - ' || SQLERRM);
END;
/
