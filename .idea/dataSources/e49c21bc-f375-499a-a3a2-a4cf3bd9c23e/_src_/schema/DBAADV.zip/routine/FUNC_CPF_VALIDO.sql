CREATE FUNCTION FUNC_CPF_VALIDO(CPF VARCHAR2)
        RETURN NUMBER
        IS
                SOMA           NUMBER;
                DIG1           NUMBER;
                DIG2           NUMBER;
                DIGITOS_IGUAIS VARCHAR2(1);
                RESULTADO      NUMBER(1);
        BEGIN
                RESULTADO      := 0;
                DIGITOS_IGUAIS := 'S';
                /*
                Verificando se os digitos são iguais
                A Principio CPF com todos o números iguais são Inválidos
                apesar de validar o Calculo do digito verificado
                EX: O CPF 00000000000 é inválido, mas pelo calculo
                Validaria
                */
                IF (CPF = '00000000000') OR (CPF = '11111111111') OR
                   (CPF = '22222222222') OR (CPF = '33333333333') OR
                   (CPF = '44444444444') OR (CPF = '55555555555') OR
                   (CPF = '66666666666') OR (CPF = '77777777777') OR
                   (CPF = '88888888888') OR (CPF = '99999999999') THEN
                        DIGITOS_IGUAIS := 'S';
                ELSE
                        DIGITOS_IGUAIS := 'N';
                END IF;
                --Caso os digitos não sejão todos iguais Começo o calculo do digitos
                IF DIGITOS_IGUAIS = 'N' THEN
                        --Cálculo do 1º dígito
                        SOMA          := 0;
                        FOR i IN 1 .. 9
                        LOOP
                            SOMA   := SOMA   + SUBSTR(CPF,i,1) * (11 - i);
                        END LOOP;
                        DIG1         := 11 - MOD (SOMA, 11);
                        IF DIG1 > 9 THEN
                           DIG1 := 0;
                        END IF;

                        -- Cálculo do 2º dígito }
                        SOMA          := 0;
                        FOR i IN 1 .. 10
                        LOOP
                            SOMA   := SOMA   + SUBSTR(CPF,i,1) * (12 - i);
                        END LOOP;
                        DIG2         := 11 - MOD (SOMA, 11);
                        IF DIG2  > 9 THEN
                           DIG2 := 0;
                        END IF;

                        -- Validando
                        IF (DIG1 = SUBSTR(CPF,10,1)) AND (DIG2 = SUBSTR(CPF,11,1)) THEN
                                RESULTADO := 1;
                        ELSE
                                RESULTADO := 0;
                        END IF;
                ELSE
                        RESULTADO := 0;
                END IF;
                RETURN RESULTADO;
        END;
/
