CREATE Procedure        tiss_identificar_it_envio (
  idItemRetorno_in IN dbamv.tiss_retorno_demon_conta_proc.id%TYPE
)

IS
  v_id_guia_envio     dbamv.tiss_retorno_demon_conta_guia.id_guia_envio%TYPE;
  v_id_it_envio       dbamv.tiss_retorno_demon_conta_proc.id_it_envio%TYPE;
  v_tp_tab_fat        dbamv.tiss_retorno_demon_conta_proc.tp_tab_fat%TYPE;
  v_cd_procedimento   dbamv.tiss_retorno_demon_conta_proc.cd_procedimento%TYPE;
  v_qt_executada      dbamv.tiss_retorno_demon_conta_proc.qt_executada%TYPE;

  Cursor c_ItemRetorno Is
    Select
        g.id_guia_envio
      , p.tp_tab_fat
      , p.cd_procedimento
      , p.qt_executada
    from dbamv.tiss_retorno_demon_conta_guia g
      inner join dbamv.tiss_retorno_demon_conta_proc p on (p.id_pai = g.id)
    where g.id_guia_envio is not null
      and p.id_it_envio is null
      and p.id = idItemRetorno_in;

  Cursor c_ItemEnvio (pIdGuia in number, pProcedimento in varchar2, pTabela in varchar2) Is
    Select
      gi1.id
    from dbamv.tiss_itguia_out gi1
    where gi1.id_pai = pIdGuia
      and to_number(gi1.cd_procedimento) = to_number(pProcedimento)
      and to_number(pTabela) in (5, 12, 18, 19, 96, 97, 98)

    union

    Select
      gi2.id
    from dbamv.tiss_itguia gi2
    where gi2.id_pai = pIdGuia
      and to_number(gi2.cd_procedimento) = to_number(pProcedimento)
      and to_number(pTabela) in (0, 16, 22)

    union

    Select
      gi3.id
    from dbamv.tiss_itguia_op gi3
    where gi3.id_pai = pIdGuia
      and to_number(gi3.cd_procedimento) = to_number(pProcedimento)
      and to_number(pTabela) = 95;
BEGIN
  -- 1. Identificar Item de Retorno
  Open  c_ItemRetorno;
  Fetch c_ItemRetorno into v_id_guia_envio, v_tp_tab_fat, v_cd_procedimento, v_qt_executada;

  -- 2. Identificar Item de Envio de acordo com o guia de envio, o procedimento e o tipo de tabela
  if c_ItemRetorno%NotFound then
    Open  c_ItemEnvio(v_id_guia_envio, v_cd_procedimento, v_tp_tab_fat);
    Fetch c_ItemEnvio INTO v_id_it_envio;
    Close c_ItemEnvio;

    Update dbamv.tiss_retorno_demon_conta_proc p Set
      p.id_it_envio = v_id_it_envio
    where p.id = idItemRetorno_in;

    Commit;
  End if;

  Close c_ItemRetorno;

  Exception
    When Others Then
      raise_application_error(-20001, 'TISS Retorno - Erro ao tentar identificar o item de envio de acordo com o item de retorno - ' || SQLCODE || ' - Error - ' || SQLERRM);
END;
/
