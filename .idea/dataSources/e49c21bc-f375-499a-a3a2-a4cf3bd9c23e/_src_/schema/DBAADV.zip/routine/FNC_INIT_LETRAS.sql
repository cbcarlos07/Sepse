CREATE function        FNC_INIT_LETRAS(DESCRICAO in VARCHAR2) return varchar2 is

  retorno VARCHAR2(1000);
  palavra VARCHAR2(1000);
  numero number(4);
  begin

    numero := REGEXP_COUNT(NVL(DESCRICAO,'VAZIO'),' ',1,'i')+1; -- recupera a quantidade de espaços.
    RETORNO := '';
  FOR I IN 1..numero

 LOOP

    palavra :=  REGEXP_SUBSTR(DESCRICAO,'[^/ ]+',1,I);  -- recupera palavra por palavra.
    IF upper(palavra) = 'UTI' THEN
       retorno := retorno || UPPER(palavra);
      ELSIF upper(palavra) = 'III' or upper(palavra) = 'II' OR upper(palavra) = 'I' THEN
         retorno := retorno || UPPER(palavra);
      ELSE
        retorno := retorno || INITCAP(palavra);
    END IF;
    retorno := retorno || ' ';
  END LOOP;
  return(retorno);
end FNC_INIT_LETRAS;
/
