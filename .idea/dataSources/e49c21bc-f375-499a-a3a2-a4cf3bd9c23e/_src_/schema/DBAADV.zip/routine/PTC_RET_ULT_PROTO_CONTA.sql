CREATE function        PTC_Ret_Ult_Proto_Conta(pCD_ATENDIME Number, pCD_REG_AMB Number, pCD_REG_FAT Number, pCD_TIP_DOC Number) return Number
is
  vCD_PROTOCOLO   NUMBER;
  vTIPO_DOC       NUMBER;

begin
  vCD_PROTOCOLO := null;

  if pCD_TIP_DOC is null then
    vTIPO_DOC := 1;
  else
    vTIPO_DOC := pCD_TIP_DOC;
  end if;

  if pCD_REG_AMB is not null then
    select cd_protocolo
    into vCD_PROTOCOLO
    from (
    select b.cd_protocolo
    from dbaadv.it_protocolo a
      join dbaadv.protocolo b on (a.cd_protocolo = b.cd_protocolo
                              and b.tp_status = 'R')
    where a.tp_verificado = 1
      and a.cd_atendimento = pCD_ATENDIME
      and a.cd_reg_amb = pCD_REG_AMB
      and a.cd_tip_doc = vTIPO_DOC
    order by b.dthr_recebido desc)
    where rownum = 1;
  end if;

  if pCD_REG_FAT is not null then
    select cd_protocolo
    into vCD_PROTOCOLO
    from (
    select d.cd_protocolo
    from dbaadv.it_protocolo c
      join dbaadv.protocolo d on (c.cd_protocolo = d.cd_protocolo
                              and d.tp_status = 'R')
    where c.tp_verificado = 1
      and c.cd_atendimento = pCD_ATENDIME
      and c.cd_reg_fat = pCD_REG_FAT
      and c.cd_tip_doc = vTIPO_DOC
    order by d.dthr_recebido desc)
    where rownum = 1;
  end if;

  return vCD_PROTOCOLO;

end;
/
