CREATE function        SenhaUsuarioMV2 (
pCD_USUARIO varchar2 ) return varchar2
is

 vSenha      varchar2(30);
 vTemp1      varchar2(30);
 vTemp2      varchar2(30);
 vTemp3      integer;
 I           integer;
 J           integer;
 TamvSenha   integer;

begin
 Select MAX(DBMS_LOB.SUBSTR(cd_senha)) KEEP (DENSE_RANK LAST ORDER BY dh_registro)

          into vSenha

      From Dbasgu.Log_Senha
     Where Cd_Usuario = pCD_USUARIO
     Order By Dh_Registro Desc;

  TamvSenha := length(vSenha);

  J := 1;

  FOR I IN 1..TamvSenha LOOP
       J := J + 2;

       vTemp1 := SUBSTR(vSenha, I, 1 );

       vTemp1 := CHR( ASCII(vTemp1) - J );

       if I = 0 then vTemp2 := vTemp1;
       else          vTemp2 := vTemp2 || vTemp1;
       end if;


  END LOOP;

  for I in 1..length(pCD_USUARIO) LOOP
    vTemp1 := SUBSTR(pCD_USUARIO, I, 1);
    vTemp2 := TRIM(LEADING vTemp1 FROM vTemp2);
  END LOOP;

  vTemp2 := TRIM(SUBSTR(vTemp2,1,LENGTH2(vTemp2)-5)); -- retirar os KKK do fim da string(que significam NULL)

  vTemp2 := TRIM(TRAILING 'K' FROM vTemp2); -- retirar os KKK do fim da string(que significam NULL)

  return (vTemp2);


end;

--grant all on dbaadv.SenhaUsuarioMV to DBAMV;
--grant all on dbaadv.SenhaUsuarioMV to DBAHAB;
--grant all on dbasgu.usuarios to dbaadv
/
